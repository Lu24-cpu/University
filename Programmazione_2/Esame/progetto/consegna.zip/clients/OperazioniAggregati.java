/*

Copyright 2024 Massimo Santini

This file is part of "Programmazione 2 @ UniMI" teaching material.

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This material is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this file.  If not, see <https://www.gnu.org/licenses/>.

*/

package clients;

import java.util.Scanner;

import eccezioni.ChangeException;
import eccezioni.ValueException;
import macchinette.Aggregato;

public class OperazioniAggregati {
    public static void main(String[] args) {
        Aggregato agg = new Aggregato();
        try(Scanner scanner = new Scanner(System.in)) {
            while(scanner.hasNextLine()){
            String s = scanner.nextLine();
            char valore = s.charAt(0);
            s = s.substring(1).trim();
            String[] parti = s.split(",");
            try{
            switch (valore){
                case '+':
                    for (String elem : parti)agg.aggiungiAggregato(Parser.parseAggregato(elem));
                    System.out.println(agg);
                    break;
                case '-':
                    Aggregato diff = new Aggregato();
                    for (String elem : parti) diff.aggiungiAggregato(Parser.parseAggregato(elem));
                    agg.rimuoviAggregato(diff);
                    System.out.println(agg);
                    break;
                default: System.out.println("Operazione non valida");
            }
            }catch(ChangeException e){System.out.println("missing-coins");}
            catch(ValueException e){System.out.println("missing-value");}
            }
        }
    }
}
