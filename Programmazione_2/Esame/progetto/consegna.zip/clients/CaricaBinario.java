/*

Copyright 2024 Massimo Santini

This file is part of "Programmazione 2 @ UniMI" teaching material.

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This material is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this file.  If not, see <https://www.gnu.org/licenses/>.

*/

package clients;

import java.util.Scanner;

import eccezioni.CapacityException;
import eccezioni.ItemException;
import eccezioni.SizeException;
import macchinette.Binario;
import macchinette.Prodotto;

public class CaricaBinario {
    public static void main(String[] args) {
        int cap = Integer.parseInt(args[0]);
        String tag = args[1];
        Binario bin = new Binario(tag, cap);
        System.out.println(bin);
        try(Scanner scanner = new Scanner(System.in)) {
            while (scanner.hasNext()){
                String line = scanner.nextLine();
                String[] parti = line.split(";");
                int qt = Integer.parseInt(parti[0]);
                Prodotto p = Parser.parseProdotto(parti[1]);
                try{
                bin.aggiungiProdotto(p, qt);
                System.out.println(bin);
                } catch (ItemException  e){System.out.println("item");} 
                catch (SizeException e){System.out.println("size");} 
                catch (CapacityException e){System.out.println("capacity");}
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
