/*

Copyright 2024 Massimo Santini

This file is part of "Programmazione 2 @ UniMI" teaching material.

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This material is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this file.  If not, see <https://www.gnu.org/licenses/>.

*/

package clients;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import eccezioni.ChangeException;
import eccezioni.EmptyException;
import eccezioni.SlotException;
import eccezioni.ValueException;
import macchinette.Aggregato;
import macchinette.Binario;
import macchinette.DistributoreAutomatico;
import macchinette.Strategia;

public class UsaDistributore {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            String s = scanner.nextLine();
            List<Binario> binario = new ArrayList<>();
            for (String elem : s.split(",")) binario.add(Parser.parseBinario(elem));
            Aggregato cassa = new Aggregato();
            String input;
            while (!(input = scanner.nextLine()).equals(".")) {
            String[] parti = input.split("\\s+");
            cassa.aggiungiAggregato(Parser.parseAggregato(parti[0] + "x" + parti[1]));
            }
            Strategia strategia = Parser.parseStrategia(scanner.nextLine());
            DistributoreAutomatico Dist = new DistributoreAutomatico(binario, cassa, strategia);
            while (scanner.hasNextLine()){
                String line = scanner.nextLine();
                char val = line.charAt(0); 
                String comando = line.substring(1);
                String[] parts = comando.split("!");
                switch (val){
                    case '+':
                        int avanzo = Dist.caricaProdotto(Parser.parseProdotto(parts[1]), Integer.parseInt(parts[0].trim()));
                        System.out.println("+ "+avanzo);
                        break;
                    case '-':
                        Aggregato disp = new Aggregato();
                        String[] partiAgg = parts[1].split(";");
                        for (String elem : partiAgg) disp.aggiungiAggregato(Parser.parseAggregato(elem));
                        try{
                        Aggregato resto = Dist.acquistaProdotto(Integer.parseInt(parts[0].trim()),disp);
                        System.out.println("- "+resto);
                        }catch(ValueException e) {System.out.println("- value");} 
                        catch(SlotException e) {System.out.println("- slot");} 
                        catch(EmptyException e) {System.out.println("- empty");} 
                        catch(ChangeException e) {System.out.println("- change");}
                        break;
                    case '?':
                        System.out.println(Dist);
                        break;
                    default:
                        System.out.println("Operazione non valida");
                }
            }
        }
    }
}
