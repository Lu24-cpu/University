/*

Copyright 2024 Massimo Santini

This file is part of "Programmazione 2 @ UniMI" teaching material.

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This material is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this file.  If not, see <https://www.gnu.org/licenses/>.

*/

package clients;

import java.util.Scanner;

import eccezioni.InvalidException;
import eccezioni.NegativeException;
import macchinette.Importo;

public class OperazioniImporti {
    public static void main(String[] args) {
        try(Scanner scanner = new Scanner(System.in)) {
            while (scanner.hasNext()) {
                String riga = scanner.nextLine();
                String[] parti = riga.split(" ");
                try{
                    Importo op1 = Parser.parseImporto(parti[0]);
                switch(parti[1]) {
                    case "+":
                        Importo ris = op1.plus(Parser.parseImporto(parti[2]));
                        System.out.println(ris);
                        break;
                    case "-":
                        Importo ris2 = op1.minus(Parser.parseImporto(parti[2]));
                        System.out.println(ris2);
                        break;
                    case "*":
                        int fattore = Integer.parseInt(parti[2]);
                        Importo ris3 = op1.multipliedBy(fattore);
                        System.out.println(ris3);
                        break;
                    case "/":
                        Integer ris4 = op1.divideBy(Parser.parseImporto(parti[2]));
                        System.out.println(ris4);
                        break;
                    default:
                        System.out.println("operazione non valida");
                }
                } catch(NumberFormatException | InvalidException e){
                    System.out.println("invalid-result");
                }catch(NegativeException e){
                    System.out.println("negative-result");
                }
            }
        }
    }
}