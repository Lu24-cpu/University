package clients;

import java.math.BigDecimal;

import eccezioni.InvalidException;
import macchinette.Aggregato;
import macchinette.Binario;
import macchinette.HighStrategia;
import macchinette.Importo;
import macchinette.InflationStrategia;
import macchinette.LowStrategia;
import macchinette.Moneta;
import macchinette.Prodotto;
import macchinette.Strategia;
import macchinette.Taglia;

/**
 * Classe di utilità responsabile del parsing dell'input testuale proveniente dai client.
 * <p>
 * Il compito del parser è tradurre stringhe fornite dall'utente in oggetti di dominio
 * validi, delegando ai tipi di dominio (ad esempio {@link MonetaEnum}) la validazione
 * dei valori ammessi.
 * </p>
 * <p>
 * In questo modo il dominio dell'applicazione non lavora mai direttamente con stringhe
 * o valori primitivi non validati, ma solo con oggetti corretti e semanticamente significativi.
 * </p>
 */
public final class Parser {

    private Parser(){}

    /**
     * Parsa una stringa in centesimi.
     * <p>
     * La stringa può rappresentare un valore in unità o centesimi, con al massimo due decimali.
     * Esempi validi: "2", "0.50", "1.00".
     * </p>
     * <p>
     * Input non valido genera {@link InvalidException} o {@link IllegalArgumentException}
     * @param s stringa da parsare in centesimi
     * @return valore parsato in centesimi
     * @throws IllegalArgumentException se la stringa è null o vuota
     * @throws InvalidException se l'input non è numerico o ha più di due decimali
     */
    private static int parseCents(String s){
        if (s == null) throw new IllegalArgumentException("Input string cannot be null");
        s = s.replaceAll("\\s+", "");
        if (s.isEmpty()) throw new IllegalArgumentException("Input string cannot be empty");
        try {
            BigDecimal bd = new BigDecimal(s);
            bd = bd.stripTrailingZeros();
            if (bd.scale() > 2) throw new InvalidException("sono presenti più di due cifre decimali");
            int totalCents = bd.multiply(BigDecimal.valueOf(100)).intValueExact();
            return totalCents;
        
        } catch (NumberFormatException e) {
        throw new InvalidException("non è un formato numericamente corretto");
        }
    }

    /**
     * Converte una stringa in un oggetto {@link Moneta}.
     * <p>
     * La stringa può rappresentare una moneta in unità o centesimi, con al massimo due decimali.
     * Esempi validi: "2", "0.50", "1.00".
     * </p>
     * <p>
     * Input non valido genera {@link InvalidException} o {@link IllegalArgumentException}:
     * <ul>
     *     <li>nei casi descritti in {@link #parseCents(String)}</li>
     *     <li>moneta di qualsiasi altro valore oltre quelli consentiti in {@link Moneta} lancia {@link InvalidException}</li>
     * </ul>
     * </p>
     *
     * @param s stringa da parsare in Moneta
     * @return oggetto {@link Moneta} corrispondente al valore numerico
     * @throws IllegalArgumentException se la stringa è null o vuota
     * @throws InvalidException se l'input non è dei tagli ammessi, non è numerico o ha più di due decimali
     */
    public static Moneta parseMoneta(String s) {
        int totalCents = parseCents(s);
        return Moneta.fromCents(totalCents);
        
    }

    /**
     * Converte una stringa in un oggetto {@link Importo}.
     * <p>
     * La stringa può rappresentare un importo in unità o centesimi, con al massimo due decimali.
     * Esempi validi: "2", "0.50", "1.00".
     * </p>
     * <p>
     * Input non valido genera {@link InvalidException} o {@link IllegalArgumentException}:
     * <ul>
     *     <li>nei casi descritti in {@link #parseCents(String)}</li>
     * </ul>
     * </p>
     *
     * @param s stringa da parsare in Importo
     * @return oggetto {@link Importo} corrispondente al valore numerico
     * @throws IllegalArgumentException se la stringa è null o vuota
     * @throws InvalidException se l'input non è numerico, ha più di due decimali
     */
    public static Importo parseImporto(String s){
        int totalCents = parseCents(s);
        return new Importo(totalCents);
    }

    /**
     * Parsea una stringa che descrive i binari nel formato:
     * {@code 30|S}.
     *
     * Per token non validi viene lanciato illegalArgumentException.
     *
     * @param s stringa contenente la descrizione dei binari
     * @return {@code Binario} dai dati specificati
     * @throws IllegalArgumentException se {@code s = null} o è vuota
     */
    public static Binario parseBinario(String s){
        if (s==null) throw new IllegalArgumentException("la stringa non può essere null");
        s = s.replaceAll("\\s+", "");
        if (s.equals("")) throw new IllegalArgumentException("la stringa non può essere vuota");
        int capacity = Integer.parseInt(s.split("\\|")[0]);
        String size = s.split("\\|")[1];
        return new Binario(size, capacity);
    }

    /**
     * Costruisce un prodotto parsando la stringa nel formato:
     * {@code "nome[|][@][;]prezzo[|][@][;]taglia"} dove solo uno dei tre simboli in parentesi quadre è presente.
     *
     * @param s stringa da parsare
     * @throws IllegalArgumentException se il formato non è valido se i valori non rispettano il RI di {@link Prodotto}
     */
    public static Prodotto parseProdotto(String s){
        s = s.replaceAll("\\s+", "");
        String[] parti = (s.contains("@")) ? s.split("\\@") : (s.contains("|")) ? s.split("\\|") : s.split(";");
        String nome = parti[0];
        Importo prezzo = parseImporto(parti[1]);
        String taglia = parti[2];
        return new Prodotto(nome, prezzo, Taglia.fromString(taglia));
    }

    /**
     * Costruisce un aggregato parsando la stringa nel formato:
     * {@code "10 [x][*] .20"} dove solo uno dei due simboli in parentesi quadre è presente.
     * Ogni token è {@code <count> x <moneta>} con possibili spazi.
     *
     * @param s la rappresentazione testuale dell'aggregato (non null)
     * @throws IllegalArgumentException se il formato o i valori non sono validi
     */
    public static Aggregato parseAggregato(String s){
        s = s.replaceAll("\\s+", "");
        String[] dettagli = (s.contains("x")) ? s.split("x") : s.split("\\*");
        int quantita = Integer.parseInt(dettagli[0]);
        Moneta moneta = parseMoneta(dettagli[1]);
        Aggregato a = new Aggregato();
        a.aggiungiMoneta(moneta, quantita);
        return a;
    }

    /**
     * Interpreta una stringa e restituisce l'implementazione di {@link Strategia} corrispondente.
     *
     * <p>Valori accettati per {@code s}:
     * <ul>
     *   <li>{@code "H"}: {@link HighStrategia}</li>
     *   <li>{@code "L"}: {@link LowStrategia}</li>
     *   <li>{@code "I"}: {@link InflationStrategia}</li>
     * </ul>
     * Qualsiasi altro valore restituisce {@code null}.
     *
     * @param s stringa che indica la strategia desiderata
     * @return un'istanza della strategia corrispondente, oppure {@code null} se il valore non è riconosciuto
     */
    public static Strategia parseStrategia(String s){
        s = s.replaceAll("\\s+", "");
        return switch (s) {
        case "H" -> new HighStrategia();
        case "L" -> new LowStrategia();
        case "I" -> new InflationStrategia();
        default -> null;
        };
    }
}
