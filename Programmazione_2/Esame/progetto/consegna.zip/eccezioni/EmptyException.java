package eccezioni;
/**
 * Eccezione lanciata quando si cerca di prelevare  da un binario vuoto.
 * <p>
 * Questa classe estende {@link Exception} ed è una checked exception.
 * </p>
 */
public class EmptyException extends Exception {
    /**
     * Identificatore di versione usato dalla serializzazione per garantire
     * la compatibilità tra oggetti serializzati e classi.
     * <p>
     * Il valore 1L indica che questa è la prima versione della classe.
     * </p>
     */
    private static final long serialVersionUID = 1L;

    /**
     * Costruisce una nuova {@code EmptyException} con un messaggio
     * descrittivo.
     *
     * @param message messaggio che descrive l’errore
     */
    public EmptyException(String message) {
        super(message);
    }

    /**
     * Costruisce una nuova {@code EmptyException} con un messaggio
     * descrittivo e una causa sottostante.
     *
     * @param message messaggio che descrive l’errore
     * @param cause eccezione originale che ha causato questa eccezione
     */
    public EmptyException(String message, Throwable cause) {
        super(message, cause);
    }
}
