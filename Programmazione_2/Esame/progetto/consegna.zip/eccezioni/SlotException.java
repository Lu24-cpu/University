package eccezioni;
/**
 * Eccezione lanciata quando si tenta di accedere ad un binario non esistente.
 * <p>
 * Questa classe estende {@link Exception} ed è una checked exception.
 * </p>
 */
public class SlotException extends Exception {
    /**
     * Identificatore di versione usato dalla serializzazione per garantire
     * la compatibilità tra oggetti serializzati e classi.
     * <p>
     * Il valore 1L indica che questa è la prima versione della classe.
     * </p>
     */
    private static final long serialVersionUID = 1L;

    /**
     * Costruisce una nuova {@code SlotException} con un messaggio
     * descrittivo.
     *
     * @param message messaggio che descrive l’errore
     */
    public SlotException(String message) {
        super(message);
    }

    /**
     * Costruisce una nuova {@code SlotException} con un messaggio
     * descrittivo e una causa sottostante.
     *
     * @param message messaggio che descrive l’errore
     * @param cause eccezione originale che ha causato questa eccezione
     */
    public SlotException(String message, Throwable cause) {
        super(message, cause);
    }
}
