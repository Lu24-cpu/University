package eccezioni;
/**
 * Eccezione lanciata quando si verifica un errore a causa del tipo di prodotto inserito in un binario.
 * <p>
 * Questa classe estende {@link Exception} ed è una checked exception.
 * </p>
 */
public class ItemException extends Exception {
    /**
     * Identificatore di versione usato dalla serializzazione per garantire
     * la compatibilità tra oggetti serializzati e classi.
     * <p>
     * Il valore 1L indica che questa è la prima versione della classe.
     * </p>
     */
    private static final long serialVersionUID = 1L;

    /**
     * Costruisce una nuova {@code ItemException} con un messaggio
     * descrittivo.
     *
     * @param message messaggio che descrive l’errore
     */
    public ItemException(String message) {
        super(message);
    }

    /**
     * Costruisce una nuova {@code ItemException} con un messaggio
     * descrittivo e una causa sottostante.
     *
     * @param message messaggio che descrive l’errore
     * @param cause eccezione originale che ha causato questa eccezione
     */
    public ItemException(String message, Throwable cause) {
        super(message, cause);
    }
}
