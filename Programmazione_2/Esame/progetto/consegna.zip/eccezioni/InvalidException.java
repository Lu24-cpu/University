package eccezioni;

/**
 * Eccezione lanciata quando si verifica un errore di input o di validazione
 * considerato “non valido” all'interno dell'applicazione.
 * <p>
 * Questa classe estende {@link RuntimeException} ed è una un-checked exception.
 * </p>
 */
public class InvalidException extends RuntimeException {
    /**
     * Identificatore di versione usato dalla serializzazione per garantire
     * la compatibilità tra oggetti serializzati e classi.
     * <p>
     * Il valore 1L indica che questa è la prima versione della classe.
     * </p>
     */
    private static final long serialVersionUID = 1L;

    /**
     * Costruisce una nuova {@code InvalidException} con un messaggio
     * descrittivo.
     *
     * @param message messaggio che descrive l’errore
     */
    public InvalidException(String message) {
        super(message);
    }

    /**
     * Costruisce una nuova {@code InvalidException} con un messaggio
     * descrittivo e una causa sottostante.
     *
     * @param message messaggio che descrive l’errore
     * @param cause eccezione originale che ha causato questa eccezione
     */
    public InvalidException(String message, Throwable cause) {
        super(message, cause);
    }
}
