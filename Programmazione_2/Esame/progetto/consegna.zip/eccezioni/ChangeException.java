package eccezioni;
/**
 * Eccezione lanciata quando si verifica un errore a causa di scarsità dei tagli di moneta.
 * <p>
 * Questa classe estende {@link Exception} ed è una checked exception.
 * </p>
 */
public class ChangeException extends Exception {
    /**
     * Identificatore di versione usato dalla serializzazione per garantire
     * la compatibilità tra oggetti serializzati e classi.
     * <p>
     * Il valore 1L indica che questa è la prima versione della classe.
     * </p>
     */
    private static final long serialVersionUID = 1L;

    /**
     * Costruisce una nuova {@code ChangeException} con un messaggio
     * descrittivo.
     *
     * @param message messaggio che descrive l’errore
     */
    public ChangeException(String message) {
        super(message);
    }

    /**
     * Costruisce una nuova {@code ChangeException} con un messaggio
     * descrittivo e una causa sottostante.
     *
     * @param message messaggio che descrive l’errore
     * @param cause eccezione originale che ha causato questa eccezione
     */
    public ChangeException(String message, Throwable cause) {
        super(message, cause);
    }
}
