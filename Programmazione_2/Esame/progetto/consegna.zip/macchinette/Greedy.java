package macchinette;

import eccezioni.ChangeException;
import eccezioni.ValueException;
/**
 * La classe astratta {@code Greedy} estende {@link Strategia} e definisce la logica di base per una strategia
 * di erogazione del resto basata sull'algoritmo greedy (ingordo).
 */
public abstract class Greedy implements Strategia{

    /*
     * Invariante di rappresentazione (RI):
     *  - Nessun vincolo, la classe non mantiene stato interno.
     *
     * Funzione di astrazione (AF):
     *  - L'oggetto rappresenta una strategia per il calcolo del resto
     *    greedy.
    */

    /**
     * costruttore di una nuova strategia greedy
     * Essendo una classe astratta, il costruttore viene richiamato dalle sottoclassi concrete.
     */
    public Greedy(){}

    /**
     * Calcola il resto secondo l'ordine descritto da {@code moneteDisponibili}
     *
     * <p>Comportamento:
     * <ul>
     *   <li>Lancia {@link ValueException} se {@code restoDaDare} è maggiore della {@code disponibilità}.</li>
     *   <li>Calcola il numero di monete da dare partendo dai tagli maggiori.</li>
     *   <li>Lancia {@link ChangeException} se non è possibile comporre esattamente {@code restoDaDare}.</li>
     *   <li>Se il resto è calcolabile, aggiorna {@code disponibilita} e restituisce l'aggregato del resto.</li>
     * </ul>
     *
     * @param restoDaDare {@link Importo} a cui deve arrivare il resto
     * @param disponibilita {@link Aggregato} da cui prelevare le monete per il resto
     * @param moneteDisponibili array di {@link Moneta} che descrive quali monete devono essere usate per cercare di ricavare il resto e in che ordine
     * @return {@link Aggregato} contenente le monete da restituire come resto
     * @throws IllegalArgumentException se {@code restoDaDare} o {@code disponibilita} sono null
     * @throws ValueException se l'importo da restituire in {@code restoDaDare} è maggiore di quanto disponibile in {@code disponibilita}
     * @throws ChangeException se alla fine non si raggiunge esattamente {@code restoDaDare}
     */
    public Aggregato stratGreedy (Importo restoDaDare,Aggregato disponibilita, Moneta[] moneteDisponibili)throws ValueException, ChangeException{
        if (restoDaDare == null || disponibilita == null || moneteDisponibili == null) throw new IllegalArgumentException("il resto da dare e la disponibilità di cassa non possono essere null");
        Aggregato resto = new Aggregato();
        if (restoDaDare.compareTo(disponibilita.getImporto()) > 0) throw new ValueException("il resto da dare è maggiore della disponibilità");

        for (Moneta moneta : moneteDisponibili) {
            int quantitaDisponibile = disponibilita.getQuantita(moneta);
            int quantitaDaDare = Math.min(quantitaDisponibile, restoDaDare.divideBy(moneta.getImporto()));
            if (quantitaDaDare > 0) {
                resto.aggiungiMoneta(moneta, quantitaDaDare);
                restoDaDare = restoDaDare.minus(moneta.getImporto().multipliedBy(quantitaDaDare));
            }
        }
        if (restoDaDare.toCents() > 0) throw new ChangeException("non è possibile completare il resto con la quantità dei vari tagli presente");
        disponibilita.rimuoviAggregato(resto);
        return resto;
    }
}
