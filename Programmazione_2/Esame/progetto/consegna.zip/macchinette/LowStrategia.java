package macchinette;

import eccezioni.ChangeException;
import eccezioni.ValueException;

/**
 * {@code LowStrategia} è una implementazione di {@link Strategia} 
 * che calcola il resto cercando di utilizzare per prime le monete di taglio minore.
 *
 * <p>
 * Questa strategia è stateless e definisce il comportamento del metodo
 * {@link #calcolaResto(Importo, Aggregato)}, lanciando eccezioni se non è
 * possibile comporre esattamente il resto richiesto con le monete disponibili.
 */

public class LowStrategia extends Greedy {
    
    /*
     * Invariante di rappresentazione (RI):
     *  - Nessun vincolo, la classe non mantiene stato interno.
     *
     * Funzione di astrazione (AF):
     *  - L'oggetto rappresenta una strategia per calcolare il resto 
     *    utilizzando prima le monete di taglio minore.
    */

    /** costruisce una LowStrategia */
    public LowStrategia(){}

    /**
     * Calcola il resto preferenziando monete di taglio minore. Il comportamento viene descritto in {@link #stratGreedy(Importo, Aggregato, Moneta[])}
     *
     * @param restoDaDare {@link Importo} a cui deve arrivare il resto (non {@code null})
     * @param disponibilita {@link Aggregato} da cui prelevare le monete per il resto (non {@code null})
     * @return {@link Aggregato} contenente le monete da restituire come resto
     * @throws IllegalArgumentException se {@code restoDaDare} o {@code disponibilita} sono null
     * @throws ValueException se l'importo da restituire in {@code restoDaDare} è maggiore di quanto disponibile in {@code disponibilita}
     * @throws ChangeException se alla fine non si raggiunge esattamente {@code restoDaDare}
     */
    @Override
    public Aggregato calcolaResto(Importo restoDaDare, Aggregato disponibilita) throws ValueException, ChangeException {
        return stratGreedy(restoDaDare, disponibilita, Moneta.values());
    }
}
