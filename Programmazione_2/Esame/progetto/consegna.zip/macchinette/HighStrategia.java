package macchinette;


import java.util.Arrays;
import java.util.Collections;

import eccezioni.ChangeException;
import eccezioni.ValueException;

/**
 * {@code HighStrategia} è una implementazione di {@link Strategia} 
 * che calcola il resto cercando di utilizzare per prime le monete di taglio maggiore.
 *
 * <p>
 * Questa strategia è stateless e definisce il comportamento del metodo {@link #calcolaResto(Importo, Aggregato)}, 
 * lanciando delle eccezioni se non è possibile comporre esattamente il resto richiesto 
 * con le monete disponibili.
 */
public class HighStrategia extends Greedy {
    
    /*
     * Invariante di rappresentazione (RI):
     *  - Nessun vincolo, la classe non mantiene stato interno.
     *
     * Funzione di astrazione (AF):
     *  - L'oggetto rappresenta una strategia per il calcolo del resto
     *    che prova a utilizzare prima le monete di taglio maggiore.
    */
    
    /** costruisce una HighStrategia */
    public HighStrategia(){}

    /**
     * Calcola il resto preferenziando monete di taglio maggiore. Il comportamento viene descritto in {@link #stratGreedy(Importo, Aggregato, Moneta[])}
     *
     * @param restoDaDare {@link Importo} a cui deve arrivare il resto
     * @param disponibilita {@link Aggregato} da cui prelevare le monete per il resto
     * @return {@link Aggregato} contenente le monete da restituire come resto
     * @throws IllegalArgumentException se {@code restoDaDare} o {@code disponibilita} sono null
     * @throws ValueException se l'importo da restituire in {@code restoDaDare} è maggiore di quanto disponibile in {@code disponibilita}
     * @throws ChangeException se alla fine non si raggiunge esattamente {@code restoDaDare}
     */
    @Override
    public Aggregato calcolaResto(Importo restoDaDare, Aggregato disponibilita) throws ValueException, ChangeException {
        Moneta[] moneteDisponibili = Moneta.values(); 
        // Inverti l'ordine direttamente sull'array originale
        Collections.reverse(Arrays.asList(moneteDisponibili));
        return stratGreedy(restoDaDare, disponibilita, moneteDisponibili);
    }
}