package macchinette;

import eccezioni.ChangeException;
import eccezioni.ValueException;

/**
 * {@code Strategia} definisce il contratto per le strategie di calcolo del resto
 * nei distributori automatici.
 * 
 * <p>
 * Le implementazioni concrete devono calcolare un insieme di monete da restituire come resto
 * a partire dalla disponibilità fornita.
 * Le modalità di selezione dei tagli di moneta e la gestione dei casi in cui vengono lanciate 
 * delle eccezioni sono lasciate all'implementazione concreta.
 *
 * <p>
 * Le strategie possono scegliere l'ordine di utilizzo dei tagli di moneta (ad esempio dal maggiore al minore o viceversa)
 * e possono ignorare alcuni tagli in base alle regole implementative.
 */
public interface Strategia {

    /*
     * Invariante di rappresentazione (RI):
     *  - L'interfaccia non definisce dati, quindi non ci sono vincoli concreti sugli stati.
     * Funzione di astrazione (AF):
     *  - Ogni implementazione rappresenta una politica per calcolare il resto da erogare
     *    a partire da una disponibilità di monete e un importo richiesto.
    */

    /**
     * Calcola il resto dell'importo richiesto utilizzando le monete presenti in {@code disponibilita}.
     *
     * <p>Comportamento:
     * <ul>
     *   <li>Se è possibile produrre esattamente {@code importo}, ritorna un {@link Aggregato} contenente le monete da dare come resto.</li>
     *   <li>Se non è possibile, lancia un'eccezione e non vengono modificati gli input.</li>
     * </ul>
     *
     * @param importo importo del resto da dare
     * @param disponibilita aggregato di monete a disposizione
     * @return {@link Aggregato} con le monete da restituire come resto
     * @throws IllegalArgumentException se {@code importo} o {@code disponibilita} sono {@code null}
     * @throws ValueException se l'importo da restituire è maggiore di quanto disponibile in {@code disponibilita}
     * @throws ChangeException se non è possibile comporre esattamente {@code importo} con le monete disponibili
     */
    Aggregato calcolaResto(Importo importo, Aggregato disponibilita) throws ValueException, ChangeException;

}