package macchinette;

import eccezioni.InvalidException;
import eccezioni.NegativeException;

/**
 * {@code Importo} rappresenta un valore monetario in unità e centesimi.
 *
 * <p>
 * Questa classe implementa {@link Comparable} per confrontare due importi.
 *
 * <p>
 * Concettualmente, un {@code Importo} è composto da una parte intera (unità) e una parte decimale (centesimi, tra 0 e 99).
 */
public class Importo implements Comparable<Importo> {
    /** unità dell'importo */
    private final int unita;
    /** centesimi dell'importo (tra 0 e 99) */
    private final int centesimi;

    /*
     * Invariante di rappresentazione (RI):
     * - unita >= 0
     * - centesimi >= 0 && centesimi <= 99
     * 
     * Funzione di astrazione (AF):
     * - L'oggetto rappresenta un importo monetario pari a (unita) unità + (centesimi) centesimi
    */

    /**
     * Costruisce un {@code Importo} a partire dal numero totale di centesimi.
     *
     * @param totalCents totale in centesimi
     * @throws InvalidException se {@code totalCents < 0}
     */
    public Importo(int totalCents) {
        if (totalCents < 0) throw new InvalidException("l'importo non può essere minore di 0");
        this.unita = totalCents / 100;
        this.centesimi = totalCents % 100;
    }
    
    /**
     * Costruisce un {@code Importo} a partire dalle unità e centesimi separati.
     *
     * @param unita unità
     * @param centesimi centesimi
     * @throws InvalidException se {@code unita < 0} o {@code centesimi < 0} o {@code centesimi > 99}
     */
    public Importo(int unita, int centesimi) {
        if (centesimi < 0 || centesimi > 99) throw new InvalidException("I centesimi devono essere compresi tra 0 e 99.");
        if (unita < 0) throw new InvalidException("Le unità non possono essere negative.");
        this.unita = unita;
        this.centesimi = centesimi;
    }
    
    /**
     * Restituisce le unità che compongono l'importo.
     *
     * @return numero di unità
     */
    public int getUnita() {
        return unita;
    }
    
    /**
     * Restituisce i centesimi che compongono l'importo.
     *
     * @return intero tra 0 e 99 che rappresenta i centesimi dell'importo
     */
    public int getCentesimi() {
        return centesimi;
    }

    /**
     * Somma questo importo con {@code other}.
     *
     * @param other importo da sommare
     * @return {@code Importo} risultante dalla somma
     * @throws IllegalArgumentException se {@code other = null}
     */
    public Importo plus(Importo other) {
        if (other == null) throw new IllegalArgumentException("l'importo da sommare non può essere null");
        int totalCentesimi = this.toCents() + other.toCents();
        return new Importo(totalCentesimi / 100, totalCentesimi % 100);
    }
    
    /**
     * Sottrae {@code other} da questo importo.
     *
     * @param other importo da sottrarre
     * @return {@code Importo} risultato della sottrazione 
     * @throws IllegalArgumentException se {@code other = null}
     * @throws NegativeException se {@code this < other}
     */
    public Importo minus(Importo other){
        if (other == null) throw new IllegalArgumentException("l'importo da sottrarre non può essere null");
        int thisTotalCentesimi = this.toCents();
        if (thisTotalCentesimi < other.toCents()) throw new NegativeException("il risultato della sottrazione è negativo");
        int otherTotalCentesimi = other.toCents();
        int resultCentesimi = thisTotalCentesimi - otherTotalCentesimi;
        return new Importo(resultCentesimi / 100, resultCentesimi % 100);
    }
    
    /**
     * Moltiplicazione per un intero non negativo.
     *
     * @param factor fattore moltiplicativo
     * @return {@code Importo} risultato della moltiplicazione
     * @throws InvalidException se {@code factor < 0}
     */
    public Importo multipliedBy(int factor) {
        if (factor < 0) throw new InvalidException("l'intero da moltiplicare non può essere minore di 0");
        int totalCentesimi = this.toCents() * factor;
        return new Importo(totalCentesimi / 100, totalCentesimi % 100);
    }
    
    /**
     * Divisione intera: il massimo n tale che {@code other * n <= this}.
     *
     * @param other divisore
     * @return quoziente intero 
     * @throws IllegalArgumentException se {@code other == null}
     * @throws InvalidException se {@code other == 0}
     */
    public int divideBy(Importo other) {
        int thisTotalCentesimi = this.toCents();
        if (other == null) throw new IllegalArgumentException("l'importo per cui dividere non può essere null");
        int otherTotalCentesimi = other.toCents();
        if(otherTotalCentesimi == 0) throw new InvalidException("l'importo per cui dividere non può essere zero");
        return thisTotalCentesimi / otherTotalCentesimi;
    }
    
    /**
     * Restituisce il totale valore dell'importo in centesimi.
     *
     * @return valore in centesimi
     */
    public int toCents() {
        return unita * 100 + centesimi;
    }

    /**
     * Rappresentazione testuale dell'importo nel formato:
     * {@code [unita unit[s]] [cents cent[s]]}, dove la parte tra parentesi quadre è opzionale a seconda che i valori 
     * siano diversi da 0 e 1
     *
     * @return stringa descrittiva dell'importo
     */
    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        if (unita > 0){
        s.append(unita).append(unita == 1 ? " unit" : " units");
        }
        if (centesimi > 0) {
            if (unita>0) s.append(" ");
            s.append(centesimi).append(centesimi == 1 ? " cent" : " cents");
        }
        return s.toString();
    }
    
    /**
     * Confronta questo importo con un altro.
     *
     * @param other importo da confrontare
     * @return valore negativo, zero o positivo se questo importo è rispettivamente
     * minore, uguale o maggiore di {@code other}
     */
    @Override
    public int compareTo(Importo other) {
        int thisTotalCentesimi = this.toCents();
        int otherTotalCentesimi = other.toCents();
        return Integer.compare(thisTotalCentesimi, otherTotalCentesimi);
    }

    /**
     * Confronta questo {@code Importo} con {@code obj} per verificarne l'uguaglianza.
     * <p>
     * Due {@code Importo} sono considerati uguali se e solo se hanno lo stesso numero
     * di unità e lo stesso numero di centesimi.
     * </p>
     *
     * @param obj l'oggetto da confrontare con questo {@code Importo}
     * @return {@code true} se l'oggetto specificato è un {@code Importo} con lo stesso
     *         valore di unità e centesimi, e {@code false} altrimenti
     */
    @Override
    public boolean equals(Object obj){
        if (this == obj) return true;
        if (!(obj instanceof Importo)) return false;
        Importo other = (Importo) obj;
        return this.unita == other.unita && this.centesimi == other.centesimi;
    }

    /**
     * Restituisce il valore hash di questo {@code Importo}
     *
     * @return il valore hash dell'importo
    */
    @Override
    public int hashCode() {
        return Integer.hashCode(toCents());
    }
}
