package macchinette;

import eccezioni.CapacityException;
import eccezioni.EmptyException;
import eccezioni.ItemException;
import eccezioni.SizeException;
/**
 * {@code Binario} rappresenta uno slot di un distributore automatico.
 * <p>
 * Un binario può contenere un numero limitato di prodotti, tutti dello stesso
 * tipo e compatibili con la taglia del binario.
 */
public class Binario {
    /** {@link Taglia} che descrive la grandezza del binario ({@code "S","M","L", "XL"}) */
    private final Taglia taglia;
    /** numero massimo di prodotti che si possono inserire nel binario */
    private final int capacita;
    /** tipologia di {@link Prodotto} presente */
    private Prodotto prodotto;
    /** quantità di {@code prodotto} presente nel binario */
    private int quantita;
    
    /*
     * Invariante di rappresentazione (RI):
     *  - taglia ammissibile per RI di Taglia
     *  - capacita > 0
     *  - quantita >= 0
     * 
     * Funzione di astrazione (AF):
     *  - L'oggetto rappresenta un contenitore con capacità massima capacita,
     *    associato a una taglia massima, che contiene una sequenza di prodotti
     *    tutti dello stesso tipo e compatibili con la taglia del contenitore.
    */

    /**
     * Costruisce un binario vuoto con la taglia e capacità specificate.
     *
     * @param taglia stringa che indica una {@link Taglia} ({@code "S","M","L", "XL"})
     * @param capacita capacità positiva (&gt;0)
     * @throws IllegalArgumentException se {@code capacita <= 0} o se la taglia è {@code null} o non è valida per {@link Taglia}
     */
    public Binario(String taglia, int capacita) {
        if (capacita <= 0) throw new IllegalArgumentException("dati inseriti non validi");
        this.taglia = Taglia.fromString(taglia);
        this.capacita = capacita;
        this.prodotto = null;
        this.quantita = 0;
    }

    /**
     * Restituisce la taglia del binario.
     * @return taglia ("S","M","L", "XL")
     */
    public Taglia getTaglia() {
        return taglia;
    }

    /**
     * Restituisce la capacità massima del binario.
     * @return capacità (maggiore di 0)
     */
    public int getCapacita() {
        return capacita;
    }

    /**
     * Restituisce il tipo di prodotto contenuto
     *
     * @return il primo {@code Prodotto} presente
     * @throws EmptyException se il binario è vuoto
     */
    public Prodotto getProdotto() throws EmptyException {
        if (quantita == 0) throw new EmptyException("il binario è vuoto");
        return prodotto;
    }

    /**
     * Dispensa (rimuove e restituisce) il primo prodotto del binario.
     *
     * @return prodotto estratto
     * @throws EmptyException se il binario è vuoto
     */
    public Prodotto dispensaProdotto() throws EmptyException{
        if (quantita == 0) throw new EmptyException("il binario è vuoto");
        this.quantita--;
        return prodotto;
    }

    /**
     * restituisce quanti altri prodotti possono essere messi nel binario.
     *
     * @return il numero di spazi disponibili
     */
    public int spazioDisponibile(){
        return capacita - quantita;
    }

    /**
     * Tenta di aggiungere {@code quantita} elementi del prodotto specificato se non ci riesce i prodotti non vengono cambiati.
     *
     * @param prodotto prodotto da inserire
     * @param quantita quantita richiesta da inserire
     * @throws IllegalArgumentException se {@code prodotto = null} o {@code quantita < 0}
     * @throws ItemException se il binario non è vuoto e il {@code prodotto} ha nome diverso dai prodotti già presenti nel binario
     * @throws SizeException se la taglia del prodotto eccede quella del binario
     * @throws CapacityException o se {@code quantita} maggiore dello spazio disponibile nel binario
     */
    public void aggiungiProdotto(Prodotto prodotto, int quantita) throws ItemException, SizeException, CapacityException {
        
        if (quantita < 0) throw new IllegalArgumentException("parametri inseriti non sono validi");
        if ((this.quantita!=0) &&(!prodotto.equals(this.prodotto))) {
                throw new ItemException("Prodotto diverso da quello già presente nel binario");
        }

        if (prodotto.taglia().compareTo(this.taglia) > 0) throw new SizeException("la taglia dell'oggetto che si cerca di inserire non è compatibile con quella del binario");
        if (spazioDisponibile() < quantita) throw new CapacityException("la quantità da inserire sommata ai prodotti inseriti supera la capacità massima");
        
        if (this.quantita == 0)this.prodotto = prodotto;
        this.quantita += quantita;
    }

    /**
     * Rimuove {@code quantita} prodotti del tipo {@code prodotto} dal binario.
     *
     * @param prodotto prodotto da rimuovere
     * @param quantita quantità da rimuovere
     * @throws IllegalArgumentException se {@code prodotto = null} o {@code quantita < 0}
     * @throws ItemException se il binario non è vuoto e il {@code prodotto} ha nome diverso dai prodotti già presenti nel binario
     * @throws SizeException se la taglia del prodotto eccede quella del binario
     * @throws CapacityException o se {@code quantita} maggiore dello spazio disponibile nel binario
     */
    public void rimuoviProdotto(Prodotto prodotto, int quantita) throws ItemException, SizeException, CapacityException{
        if (quantita <= 0) throw new IllegalArgumentException("parametri inseriti non validi");
        if ((this.quantita!=0) &&(!prodotto.equals(this.prodotto))) {
                throw new ItemException("Prodotto diverso da quello già presente nel binario");
        }
        if (prodotto.taglia().compareTo(this.taglia) > 0) throw new SizeException("Taglia del prodotto non compatibile con il binario");
        if (this.quantita < quantita) throw new CapacityException("La quantità da rimuovere è maggiore di quella presente");
        this.quantita -= quantita;
        if (this.quantita == 0) this.prodotto = null;
    }

    /**
     * Rappresentazione testuale del binario nel formato:
     * {@code <prodotto, taglia, quantità, capacità>} dove prodotto è {@code "-"} se vuoto o la rappresentazione del primo prodotto.
     *
     * @return stringa descrittiva del binario
     */
    @Override
    public String toString() {
        StringBuilder s = new StringBuilder("<");
        if (quantita == 0)s.append("-, ");
        else s.append(prodotto.toString()).append(", ");
        s.append(taglia).append(", ").append(this.quantita).append(", ").append(capacita).append(">");
        return s.toString();
    }
}
