package macchinette;
/**
 * {@code Taglia} rappresenta la taglia di un prodotto vendibile da un distributore automatico.
 *
 * <p>
 * Le taglie possibili sono:
 * <ul>
 *   <li>{@code S} - Small</li>
 *   <li>{@code M} - Medium</li>
 *   <li>{@code L} - Large</li>
 *   <li>{@code XL} - Extra Large</li>
 * </ul>
 */
public enum Taglia {
    /** taglia small */
    SMALL("S"),
    /** taglia medium */
    MEDIUM("M"),
    /** taglia large */
    LARGE("L"),
    /** taglia extra large */
    EXTRA_LARGE("XL");
    /** simbolo della taglia */
    private final String simbolo;

    /*
     * Invariante di rappresentazione (RI):
     * - simbolo corrisponde a uno delle taglie ammesse
     * 
     * Funzione di astrazione (AF):
     * - Ogni costante rappresenta una taglia fisica del prodotto come stringa
    */

    /**
     * Costruisce una Taglia con il dato valore in stringa.
     *
     * @param s stringa contenente la taglia
     */
    private Taglia(String s){
        this.simbolo = s;
    }

    /**
     * Restituisce l'oggetto Taglia con il valore in {@code s} se presente.
     *
     * @param s stringa da cercare tra le taglie
     * @return taglia del corrispondente valore
     * @throws IllegalArgumentException se s non è compreso tra le taglie ammissibili o è {@code null}
     */
    public static Taglia fromString(String s) {
        if (s==null) throw new IllegalArgumentException("la taglia scelta non può essere nulla");
        for (Taglia m : values()) {
            if (m.simbolo.equals(s))
                return m;
        }
        throw new IllegalArgumentException("la taglia scelta non è valida");
    }

    /**
     * Restituisce la rappresentazione testuale di questa {@code Taglia}.
     * <p>
     * Il valore restituito corrisponde al simbolo associato alla taglia
     *
     * @return il simbolo della taglia come stringa
    */
    @Override
    public String toString(){
        return simbolo;
    }
}
