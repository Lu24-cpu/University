package macchinette;

import java.util.Arrays;

import eccezioni.ChangeException;
import eccezioni.ValueException;

/**
 * {@code InflationStrategia} è una implementazione di {@link Strategia} 
 * che calcola il resto considerando solo monete di taglio superiore o uguale a 10 centesimi.
 *
 * <p>
 * Questa strategia simula un'economia in cui le monete piccole non hanno più valore:
 * eventuali centesimi inferiori a 10 vengono ignorati.
 *
 * <p>
 * Il metodo {@link #calcolaResto(Importo, Aggregato)} lancia eccezioni se non è possibile 
 * comporre esattamente il resto arrotondato al difetto con le monete disponibili.
 */
public class InflationStrategia extends Greedy{

    /*
     * Invariante di rappresentazione (RI):
     *  - Nessun vincolo, la classe non mantiene stato interno.
     *
     * Funzione di astrazione (AF):
     *  - L'oggetto rappresenta una strategia per calcolare il resto 
     *    usando solo monete di taglio ≥ 10 centesimi, arrotondando il resto al difetto.
    */

    /** costruisce una InflationStrategia */
    public InflationStrategia(){}

    /**
     * Calcola il resto ignorando i tagli inferiori a 10 centesimi. Il comportamento viene descritto in {@link #stratGreedy(Importo, Aggregato, Moneta[])}
     * 
     * @param restoDaDare {@link Importo} a cui deve arrivare il resto
     * @param disponibilita {@link Aggregato} da cui prelevare le monete
     * @return {@link Aggregato} con il resto erogato (arrotondato per difetto)
     * @throws IllegalArgumentException se {@code restoDaDare} o {@code disponibilita} sono null
     * @throws ValueException se l'importo da restituire è maggiore di quanto disponibile in {@code disponibilita}
     * @throws ChangeException se alla fine non si raggiunge esattamente il resto da dare
     */
    @Override
    public Aggregato calcolaResto(Importo restoDaDare, Aggregato disponibilita) throws ValueException, ChangeException{
        if (restoDaDare == null) throw new IllegalArgumentException("il resto da dare non può essere null");
        Moneta[] moneteDisponibili = Arrays.stream(Moneta.values()).filter(m -> m.getImporto().toCents() >= 10).toArray(Moneta[]::new);
        Importo importoEffettivo = new Importo ((restoDaDare.toCents() / 10) * 10);
        return stratGreedy(importoEffettivo, disponibilita, moneteDisponibili);
    }

}
