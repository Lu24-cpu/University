package macchinette;

import eccezioni.InvalidException;
/**
 * {@code Moneta} rappresenta un taglio monetario fisso.
 *
 * <p>
 * Ogni costante enum corrisponde a un taglio valido, da 1 centesimo a 2 euro.
 *
 * <p>
 * Nota:
 * <ul>
 *   <li>Non mantiene una mappa delle istanze: la gestione delle quantità di monete è affidata a {@link Aggregato}.</li>
 * </ul>
 */
public enum Moneta {
    /** moneta da un centesimo */
    UNO_CENT(new Importo(1)),
    /** moneta da due centesimi */
    DUE_CENT(new Importo(2)),
    /** moneta da cinque centesimi */
    CINQUE_CENT(new Importo(5)),
    /** moneta da dieci centesimi */
    DIECI_CENT(new Importo(10)),
    /** moneta da venti centesimi */
    VENTI_CENT(new Importo(20)),
    /** moneta da cinquanta centesimi */
    CINQUANTA_CENT(new Importo(50)),
    /** moneta da un euro */
    UN_EURO(new Importo(100)),
    /** moneta da due euro */
    DUE_EURO(new Importo(200));

    /**importo del valore*/
    private final Importo importo;
    
    /*
     * Invariante di rappresentazione (RI):
     * - importo corrisponde a uno dei tagli ammessi
     * 
     * Funzione di astrazione (AF):
     * - L'oggetto rappresenta un taglio monetario come un {@link Importo}
    */

    /**
     * Costruisce una Moneta con il dato valore.
     *
     * @param valore valore in imoporto
     */
    private Moneta(Importo valore) {
        this.importo = valore;
    }

    /**
     * Restituisce l'oggetto Moneta con il valore in {@code cents}.
     *
     * @param cents valore in centesimi
     * @return moneta del corrispondente valore
     * @throws InvalidException se cents non è compreso tra i tagli di valore ammissibili
     */
    public static Moneta fromCents(int cents) {
        for (Moneta m : values()) {
            if (m.importo.toCents() == cents)
                return m;
        }
        throw new InvalidException("l'ammontare scelto non è compreso nei tagli ammessi");
    }

    /**
     * Restituisce l'oggetto Moneta con il valore in {@code cents}.
     *
     * @param valore valore in Importo
     * @return moneta del corrispondente valore
     * @throws InvalidException se cents non è compreso tra i tagli di valore ammissibili
     */
    public static Moneta fromImporto(Importo valore) {
        for (Moneta m : values()) {
            if (m.importo.equals(valore))
                return m;
        }
        throw new InvalidException("l'ammontare scelto non è compreso nei tagli ammessi");
    }

    /**
     * Restituisce l'Importo corrispondente a questa moneta.
     * @return {@link Importo} rappresentante il valore di questa moneta
     */
    public Importo getImporto() {
        return importo;
    }

    /**
     * Rappresentazione testuale della moneta nel formato:
     * {@code [unita unit[s]] [cents cent[s]]}, dove la parte tra parentesi quadre è opzionale a seconda che i valori 
     * siano diversi da 0 e 1
     *
     * @return stringa descrittiva della moneta
     */
    @Override
    public String toString() {
        return (importo.toString());
    }
    
}
