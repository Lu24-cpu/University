package macchinette;

import java.util.Objects;

/**
 * {@code Prodotto} rappresenta un articolo vendibile da un distributore automatico.
 *
 * <p>
 * Ogni prodotto ha un nome descrittivo, un prezzo e una taglia. 
 * La taglia è un valore di tipo {@link Taglia} (ad esempio {@code "S","M", "L" o "XL"}).
 *
 * <p>
 * Questa classe è immutabile e implementa {@link Comparable} per confrontare prodotti.
 * @param nome nome del prodotto
 * @param prezzo {@link Importo} del prezzo del prodotto
 * @param taglia taglia del prodotto come stringa ({@code "S","M","L","XL"})
 */
public record Prodotto(String nome, Importo prezzo, Taglia taglia) implements Comparable<Prodotto> {
    
    /*
     * Invariante di rappresentazione (RI):
     *  - nome != null && !nome.isEmpty()
     *  - prezzo != null
     *  - taglia è istanza di {@link Taglia}
     * 
     * Funzione di astrazione (AF):
     *  - L'oggetto rappresenta un prodotto vendibile con un nome, un prezzo e una taglia
    */

    /**
     * Costruisce un prodotto dai campi espliciti.
     *
     * <p>
     * La taglia passata come stringa viene convertita internamente in un valore dell'enum {@link Taglia}.
     *
     * @throws IllegalArgumentException se uno dei parametri è {@code null} o {@code nome} è vuoto
     */
    public Prodotto{
        if (nome == null || nome.equals("") || prezzo == null || taglia == null) throw new IllegalArgumentException("i parametri inseiti non sono validi");
    }

    /**
     * Confronta questo prodotto con un altro secondo l'ordinamento naturale.
     * (taglia, nome, prezzo)
     *
     * @param other prodotto da confrontare
     * @return valore negativo, zero o positivo se questo prodotto è
     *         rispettivamente minore, uguale o maggiore di {@code other}
     * @throws IllegalArgumentException se {@code other} è {@code null}
     */
    @Override
    public int compareTo(Prodotto other) {
        if (other == null) throw new IllegalArgumentException("l'aggregato da comparare non può essere null");
        int tagliaComparison = this.taglia.compareTo(other.taglia);
        if (tagliaComparison != 0) {return tagliaComparison;}
        int nomeComparison = this.nome.compareTo(other.nome);
        if (nomeComparison != 0) {return nomeComparison;}
        return this.prezzo.compareTo(other.prezzo);
    }

    /**
     * Rappresentazione testuale del prodotto nel formato:
     * {@code "<nome, prezzo, taglia>"}.
     *
     * @return stringa descrittiva del prodotto
     */
    @Override
    public String toString(){
        return ("<"+nome+", "+prezzo.toString()+", "+taglia+">");
    }

    /**
     * Confronta questo {@code Prodotto} con {@code obj} per verificarne l'uguaglianza.
     * <p>
     * Due {@code Prodotto} sono considerati uguali se hanno lo stesso nome,
     * lo stesso prezzo e la stessa taglia.
     * </p>
     *
     * @param obj l'oggetto da confrontare
     * @return {@code true} se l'oggetto specificato rappresenta lo stesso prodotto;
     *         {@code false} altrimenti
    */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Prodotto)) return false;
        Prodotto prodotto = (Prodotto) obj;
        return (taglia.equals(prodotto.taglia)) &&
                Objects.equals(nome, prodotto.nome) &&
                Objects.equals(prezzo, prodotto.prezzo);
    }

    /**
     * Restituisce il valore hash di questo {@code Prodotto}.
     *
     * @return il valore hash del prodotto
    */
    @Override
    public int hashCode() {
        return Objects.hash(taglia, nome, prezzo);
    }
}
