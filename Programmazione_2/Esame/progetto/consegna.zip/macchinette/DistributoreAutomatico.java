package macchinette;

import java.util.List;

import eccezioni.CapacityException;
import eccezioni.ChangeException;
import eccezioni.EmptyException;
import eccezioni.ItemException;
import eccezioni.SizeException;
import eccezioni.SlotException;
import eccezioni.ValueException;
/**
 * {@code DistributoreAutomatico} coordina i binari, la cassa e
 * la politica di calcolo del resto.
 * <p>
 * Un distributore automatico gestisce l'erogazione dei prodotti,
 * l'accettazione delle monete e il calcolo del resto secondo
 * una strategia configurabile.
 */
public class DistributoreAutomatico{
    /** Lista di {@link Binario} nel distributore */
    private final List<Binario> binari;
    /** {@link Aggregato} che rappresenta la cassa del distributore */
    private final Aggregato cassa;
    /** una delle tre implementazioni di {@link Strategia} o di default {@link HighStrategia} */
    private final Strategia strategia;

    /*
     * Invariante di rappresentazione (RI):
     *  - binari ≠ null
     *  - cassa ≠ null ∧ cassa verifica le RI di Aggregato
     *  - strategia ≠ null
     * 
     * Funzione di astrazione (AF):
     *  - L'oggetto rappresenta un distributore automatico
     *    dotato di un insieme di binari, di una cassa di monete
     *    e di una politica per il calcolo del resto.
    */

    /**
     * Costruisce un distributore automatico a partire dai binari,
     * dalla cassa iniziale e dalla strategia per il calcolo del resto.
     *
     * @param bin lista di binari
     * @param cassa aggregato della cassa del distributore
     * @param strat strategia per il resto; se {@code null} viene usata {@link HighStrategia} come default
     * @throws IllegalArgumentException se {@code bin = null} o {@code cassa = null}
     */
    public DistributoreAutomatico(List<Binario> bin, Aggregato cassa, Strategia strat) {
        if (bin == null || cassa == null) throw new IllegalArgumentException("parametri inseriti non sono validi");
        this.strategia = (strat == null) ? new HighStrategia() : strat;
        this.binari = bin;
        this.cassa = cassa;
    }

    /**
     * Restituisce l'importo totale presente in cassa.
     *
     * @return {@link Importo} della cassa
     */
    public Importo getImportoCassa(){
        return cassa.getImporto();
    }

    /**
     * Svuota completamente la cassa.
     *
     * <p>Comportamento: {@code cassa} diventa vuota.
     */
    public void svuotaCassa() {
        cassa.svuota();
    }

    /**
     * Aggiunge all'interno della cassa le monete dell'aggregato fornito.
     *
     * @param other {@link Aggregato} da aggiungere
     * @throws IllegalArgumentException se {@code other = null}
     */
    public void aggiungiCassa(Aggregato other){
        if (other == null) throw new IllegalArgumentException("l'aggregato da aggiungere non può essere null");
        cassa.aggiungiAggregato(other);
    }

    /**
     * Carica la quantità richiesta del prodotto distribuendo il carico sui binari (in ordine).
     *
     * <p>Comportamento: per ogni binario viene aggiornata la quantità e viene retituito il numero di prodotti non caricati.
     *
     * @param prodotto prodotto da caricare
     * @param quantita quantità totale da caricare
     * @return numero di prodotti non caricati
     * @throws IllegalArgumentException se {@code prodotto = null} o {@code quantita < 0}
     */
    public int caricaProdotto(Prodotto prodotto, int quantita) {
        if (prodotto == null || quantita < 0) throw new IllegalArgumentException("i parametri inseriti non sono validi"); 
        for (Binario elem : binari) {
            try{
            int qt = Math.min(elem.spazioDisponibile(), quantita);
            elem.aggiungiProdotto(prodotto, qt);
            quantita -= qt;
            if (quantita == 0) return quantita;
            }catch (ItemException | CapacityException | SizeException e){}
        }
        return quantita;
    }

    /**
     * Esegue l'acquisto da un binario dato, tentando di dare il resto.
     * <p>
     * Comportamento:
     * <ul>
     *  <li>Lancia delle eccezioni se {@code indiceBinario} non valido, se il binario è vuoto, o se il pagamento è insufficiente</li>
     *  <li>Tenta di calcolare il resto tramite la {@code strategia}.Se la strategia non riesce viene lanciata un eccezione</li>
     *  <li>Altrimenti dispensa il prodotto, aggiorna la {@code cassa} e il {@code pagamento} e restituisce un {@link Aggregato} corrispondente al resto.</li>
     * </ul>
     * @param indiceBinario indice del binario da cui erogare
     * @param pagamento {@link Aggregato} usato per pagare
     * @return {@link Aggregato} del resto se l'acquisto è riuscito
     * @throws SlotException se l'indice del binario non è valido
     * @throws EmptyException se il binario è vuoto
     * @throws ValueException se il pagamento è insufficiente
     * @throws ChangeException se non è possibile dare il resto
     */
    public Aggregato acquistaProdotto(int indiceBinario, Aggregato pagamento) throws SlotException, EmptyException, ValueException, ChangeException{
        if (indiceBinario < 0 || indiceBinario >= binari.size()) throw new SlotException("indice indica un binario inesistente");
        
        Binario binario = binari.get(indiceBinario);
        Prodotto prodotto = binario.getProdotto();

        Importo prezzo = prodotto.prezzo();
        Importo importoPagamento = pagamento.getImporto();
        if (importoPagamento.compareTo(prezzo) < 0) throw new ValueException("pagamento insufficiente per effettuare l'acquisto");

        Aggregato copyCassa = new Aggregato();
        copyCassa.aggiungiAggregato(cassa);
        copyCassa.aggiungiAggregato(pagamento);

        Importo restoImporto = importoPagamento.minus(prezzo);
        Aggregato resto = strategia.calcolaResto(restoImporto, copyCassa);
        pagamento.svuota();
        pagamento.aggiungiAggregato(resto);
        cassa.svuota();
        cassa.aggiungiAggregato(copyCassa);
        
        binario.dispensaProdotto();
        return resto;
    }
    
    /**
     * Rappresentazione testuale del distributore nel formato:
     * {@code "? numero del binario | nome del prodotto | prezzo del prodotto"} dove il prodotto è il primo prodotto del binario di quel numero,
     * ripetuta per tutti i binari non vuoti del distributore
     *
     * @return stringa descrittiva del distributore
     */
    @Override
    public String toString() {
        String s = "";
        int i = 0;
        for (Binario elm : binari) {
            try {
                elm.getProdotto();
                if (i!=0) s = s + "\n";
                s = s + "? " + i + " | " + binari.get(i).getProdotto().nome() + " | " + binari.get(i).getProdotto().prezzo();
            } catch (EmptyException e) {}
            i++;
        }
        return s;
    }
}
