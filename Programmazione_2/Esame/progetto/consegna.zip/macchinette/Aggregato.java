package macchinette;

import java.util.HashMap;
import java.util.Map;

import eccezioni.ChangeException;
import eccezioni.ValueException;

/**
 * {@code Aggregato} rappresenta un multinsieme di {@link Moneta}.
 *<p>
 * Un aggregato mantiene, per ciascun tipo di moneta, il numero di esemplari
 * presenti, consentendo di modellare collezioni di monete anche con ripetizioni.
 */
public class Aggregato {
    /** mappa che relaziona un tipo di {@link Moneta} con la sua quantità */
    private final Map<Moneta, Integer> quantitaMonete;
    
    /*
     * Invariante di rappresentazione (RI):
     *  - quantitaMonete ≠ null
     *  - ∀ m ∈ quantitaMonete.keySet() : quantitaMonete.get(m) > 0
     * 
     * Funzione di astrazione (AF):
     *  - L'oggetto rappresenta un multinsieme di monete in cui,
     *    per ogni tipo di moneta m, la molteplicità di m è pari
     *    al valore associato a m nell'oggetto astratto.
    */
    
    /**
     * Costruttore di un aggregato vuoto.
     */
    public Aggregato() {
        this.quantitaMonete = new HashMap<>();
    }

    /**
     * Aggiunge tutte le monete dell'altro aggregato a questo aggregato.
     *
     * <p>
     * Successivamente alla chiamata per ogni (moneta {@code m}, numero {@code n}) 
     * in {@code other}, {@code getQuantita(m)} aumenta di {@code n}.
     *
     * @param other aggregato da aggiungere
     * @throws IllegalArgumentException se {@code other = null}
     */
    public void aggiungiAggregato(Aggregato other) {
        if (other == null) throw new IllegalArgumentException("il valore inserito è null");
        for (Map.Entry<Moneta, Integer> entry : other.quantitaMonete.entrySet()) {
            Moneta moneta = entry.getKey();
            int quantita = entry.getValue();
            aggiungiMoneta(moneta, quantita);
        }
    }

    /**
     * Aggiunge {@code quantita} monete del tipo {@code moneta} a questo aggregato.
     *
     * @param moneta tipo di moneta da aggiungere
     * @param quantita numero di monete da aggiungere
     * @throws IllegalArgumentException se {@code quantita < 0} o {@code moneta = null}
     */
    public void aggiungiMoneta(Moneta moneta, int quantita) {
        if (quantita < 0) throw new IllegalArgumentException("la quantità inserita è < 0");
        if (moneta == null) throw new IllegalArgumentException("la moneta inserita moneta è null");
        quantitaMonete.put(moneta, quantitaMonete.getOrDefault(moneta, 0) + quantita);
    }

    /**
     * Rimuove le monete dell'aggregato {@code other} da questo aggregato se possibile.
     *<p>
     * Comportamento:
     * <ul>
     *  <li>Cerca di rimuovere le monete richieste altrimenti la modifica non avviene.</li>
     * </ul>
     *
     * @param other aggregato da rimuovere
     * @throws IllegalArgumentException se {@code other = null}
     * @throws ValueException se il valore totale di {@code this} è minore di quello di {@code other} 
     * @throws ChangeException se per qualche taglio non sono presenti abbastanza monete
     */
    public void rimuoviAggregato(Aggregato other) throws ValueException, ChangeException{
        if (other == null) throw new IllegalArgumentException("valore inserito non può essere null");
        if (this.getImporto().compareTo(other.getImporto()) < 0) throw new ValueException("il valore da rimuovere è maggiore di quello presente");
        Aggregato copia = new Aggregato();
        copia.aggiungiAggregato(this);
        
        for (Map.Entry<Moneta, Integer> entry : other.quantitaMonete.entrySet()) {
            Moneta moneta = entry.getKey();
            int quantita = entry.getValue();
            copia.rimuoviMoneta(moneta, quantita);
        }
        this.svuota();
        this.aggiungiAggregato(copia);
    }

    /**
     * Rimuove {@code quantita} monete del tipo {@code moneta} da questo aggregato.
     *
     * Comportamento: se  riesce decrementa la quantità dalla moneta altrimenti non modifica l'aggregato
     *
     * @param moneta tipo di moneta da rimuovere
     * @param quantita numero di monete da rimuovere
     * @throws IllegalArgumentException se {@code quantita <= 0} o se {@code moneta} è null
     * @throws ChangeException se non ci sono abbastanza monete
     */
    public void rimuoviMoneta(Moneta moneta, int quantita) throws ChangeException{
        if (moneta == null || quantita <= 0) throw new IllegalArgumentException("valore inseriti non validi");
        Integer have = quantitaMonete.getOrDefault(moneta, 0);
        if (have < quantita) throw new ChangeException("quantità di monete non sufficiente per la rimozione");
        int nuovaQuantita = have - quantita;
        if (nuovaQuantita == 0) {
            quantitaMonete.remove(moneta);
        } else {
            quantitaMonete.put(moneta, nuovaQuantita);
        }
    }

    /**
     * Svuota completamente l'aggregato {@code this} rimuovendo tutte le monete.
     */
    public void svuota() {
        quantitaMonete.clear();
    }

    /**
     * Restituisce la quantità di monete del tipo {@code moneta} presenti nell'aggregato.
     *
     * @param moneta tipo di moneta (non null)
     * @return numero di monete presenti (maggiore di 0) o se la moneta non è presenta o non è valida 0
     */
    public int getQuantita(Moneta moneta) {
        return quantitaMonete.getOrDefault(moneta, 0);
    }

    /**
     * Calcola e restituisce il valore totale dell'aggregato come {@link Importo}.
     *
     * @return Importo corrispondente al totale delle monete contenute
     */
    public Importo getImporto() {
        Importo totaleImporto = new Importo(0);
        for (Map.Entry<Moneta, Integer> entry : quantitaMonete.entrySet()) {
            Moneta moneta = entry.getKey();
            int quantita = entry.getValue();
            totaleImporto = totaleImporto.plus(moneta.getImporto().multipliedBy(quantita));
        }
        return totaleImporto;
    }

    /**
     * Rappresentazione testuale dell'aggregato
     * es. {@code <10 x 5 cents, 10 x 10 cents, 10 x 20 cents, 10 x 1 unit>}.
     *
     * <p>Nota: i tagli sono elencati seguendo l'ordine definito 1,2,5,10,20,50,100,200.
     *
     * @return stringa formattata
     */
    @Override
    public String toString() {
        Moneta[] moneteDisponibili = Moneta.values();
        StringBuilder sb = new StringBuilder("<");
        boolean first = true;
        for (Moneta moneta : moneteDisponibili) {
            int qt = quantitaMonete.getOrDefault(moneta, 0);
            if (qt == 0) continue;
            if (!first){sb.append(", ");}
            first = false;
            sb.append(qt).append(" x ").append(moneta.toString());
        }
        sb.append(">");
        return sb.toString();
    }
}
